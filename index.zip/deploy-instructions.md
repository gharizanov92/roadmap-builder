# AWS EC2 Deployment Instructions

## Prerequisites
- EC2 instance running (Ubuntu/Amazon Linux)
- SSH access to the instance
- Security group allowing HTTP (port 80) and HTTPS (port 443)

## Step 1: Prepare the Deployment Package

All your HTML files are ready. We'll create a deployment script.

## Step 2: Connect to EC2 and Install nginx

```bash
# SSH into your EC2 instance
ssh -i your-key.pem ec2-user@your-ec2-ip

# Update system
sudo yum update -y  # For Amazon Linux
# OR
sudo apt update && sudo apt upgrade -y  # For Ubuntu

# Install nginx
sudo yum install nginx -y  # For Amazon Linux
# OR
sudo apt install nginx -y  # For Ubuntu

# Install apache2-utils for password generation
sudo yum install httpd-tools -y  # For Amazon Linux
# OR
sudo apt install apache2-utils -y  # For Ubuntu
```

## Step 3: Create Password File

```bash
# Create a password file with username and password
# Replace 'admin' with your desired username
sudo htpasswd -c /etc/nginx/.htpasswd admin

# Or create with a specific password (non-interactive)
echo "admin:$(openssl passwd -apr1 'your-20-digit-password')" | sudo tee /etc/nginx/.htpasswd
```

## Step 4: Upload Your Files

From your local machine:

```bash
# Create a zip of your project files
# (Run this from your project directory)
zip -r gantt-app.zip *.html *.js *.md -x "*.git*" -x "node_modules/*"

# Upload to EC2
scp -i your-key.pem gantt-app.zip ec2-user@your-ec2-ip:/tmp/
```

## Step 5: Extract and Configure on EC2

```bash
# SSH back into EC2
ssh -i your-key.pem ec2-user@your-ec2-ip

# Create web directory
sudo mkdir -p /var/www/gantt-app

# Extract files
sudo unzip /tmp/gantt-app.zip -d /var/www/gantt-app

# Set permissions
sudo chown -R nginx:nginx /var/www/gantt-app  # Amazon Linux
# OR
sudo chown -R www-data:www-data /var/www/gantt-app  # Ubuntu
```

## Step 6: Configure nginx

See the `nginx-config.conf` file for the configuration.

```bash
# Copy the config
sudo cp /var/www/gantt-app/nginx-config.conf /etc/nginx/conf.d/gantt-app.conf

# Test nginx configuration
sudo nginx -t

# Restart nginx
sudo systemctl restart nginx
sudo systemctl enable nginx
```

## Step 7: Access Your Application

Open your browser and navigate to:
```
http://your-ec2-public-ip
```

You'll be prompted for username and password.

## Security Notes

1. **Use HTTPS in production** - Set up Let's Encrypt SSL certificate
2. **Change default password** - Use a strong 20-character password
3. **Restrict Security Group** - Only allow access from specific IPs if possible
4. **Regular Updates** - Keep nginx and system packages updated

## Troubleshooting

```bash
# Check nginx status
sudo systemctl status nginx

# View nginx error logs
sudo tail -f /var/log/nginx/error.log

# View nginx access logs
sudo tail -f /var/log/nginx/access.log

# Check if port 80 is open
sudo netstat -tlnp | grep :80
```

## Optional: Set Up HTTPS with Let's Encrypt

```bash
# Install certbot
sudo yum install certbot python3-certbot-nginx -y  # Amazon Linux
# OR
sudo apt install certbot python3-certbot-nginx -y  # Ubuntu

# Get SSL certificate (requires domain name)
sudo certbot --nginx -d your-domain.com

# Auto-renewal is set up automatically
```
