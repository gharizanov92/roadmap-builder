#!/bin/bash

# Deployment script for Gantt App
# Usage: ./deploy.sh <ec2-ip> <path-to-key.pem>

set -e

EC2_IP=$1
KEY_PATH=$2
USERNAME="admin"
PASSWORD="$(openssl rand -base64 20 | tr -d '/+=' | cut -c1-20)"

if [ -z "$EC2_IP" ] || [ -z "$KEY_PATH" ]; then
    echo "Usage: ./deploy.sh <ec2-ip> <path-to-key.pem>"
    exit 1
fi

echo "=========================================="
echo "Deploying Gantt App to EC2"
echo "=========================================="
echo ""

# Step 1: Create deployment package
echo "Step 1: Creating deployment package..."
zip -r gantt-app.zip *.html *.js nginx-config.conf -x "*.git*" -x "node_modules/*" -x "*.md"
echo "✓ Package created"
echo ""

# Step 2: Upload to EC2
echo "Step 2: Uploading to EC2..."
scp -i "$KEY_PATH" gantt-app.zip ec2-user@$EC2_IP:/tmp/
echo "✓ Files uploaded"
echo ""

# Step 3: Install and configure on EC2
echo "Step 3: Installing and configuring..."
ssh -i "$KEY_PATH" ec2-user@$EC2_IP << 'ENDSSH'
# Update system
sudo yum update -y

# Install nginx and tools
sudo yum install nginx httpd-tools -y

# Create web directory
sudo mkdir -p /var/www/gantt-app

# Extract files
sudo unzip -o /tmp/gantt-app.zip -d /var/www/gantt-app

# Set permissions
sudo chown -R nginx:nginx /var/www/gantt-app

# Copy nginx config
sudo cp /var/www/gantt-app/nginx-config.conf /etc/nginx/conf.d/gantt-app.conf

# Remove default config if exists
sudo rm -f /etc/nginx/conf.d/default.conf

# Test nginx config
sudo nginx -t

# Start nginx
sudo systemctl start nginx
sudo systemctl enable nginx

echo "✓ nginx configured and started"
ENDSSH

# Step 4: Create password
echo "Step 4: Setting up authentication..."
ssh -i "$KEY_PATH" ec2-user@$EC2_IP "echo '$USERNAME:$(openssl passwd -apr1 $PASSWORD)' | sudo tee /etc/nginx/.htpasswd > /dev/null"
ssh -i "$KEY_PATH" ec2-user@$EC2_IP "sudo systemctl restart nginx"
echo "✓ Authentication configured"
echo ""

# Cleanup
rm gantt-app.zip

echo "=========================================="
echo "Deployment Complete!"
echo "=========================================="
echo ""
echo "Access your application at: http://$EC2_IP"
echo ""
echo "Login Credentials:"
echo "  Username: $USERNAME"
echo "  Password: $PASSWORD"
echo ""
echo "⚠️  SAVE THESE CREDENTIALS - They won't be shown again!"
echo ""
echo "To change the password later, run on EC2:"
echo "  sudo htpasswd /etc/nginx/.htpasswd $USERNAME"
echo ""
